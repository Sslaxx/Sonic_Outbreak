Powered by the **[Godot Engine](https://godotengine.org/)**.

**HEADS:**
- Jesse (Blitzer) - Creative Director, Project Management, Coding, Level Designer, Background Artist
- Viizen - Creative Director, Project Management, Concept Artist

**LEVEL DESIGN:**
- Cris Nail Bidoof - Level Designer, Conceptualizer
- Kalin - Level Designer
- jubbalub - Level Designer
- Ozaleto - Level Designer, FM OST

**CODERS:**
- Sslaxx - Coding: UI

**CONCEPT ARTISTS:**
- Out of Discord for a while. - Concept Artist - Character Designs
- vinpie - Character Painting

**2D ARTISTS:**
- /b/ - Spriter - Characters, Enemies
- EggmanInc - Spriter - Enemies
- LuchoJN - Spriter - Miscellaneous, Assistance

**3D ARTISTS:**
- XavierGibbons  - Modeler, 3D Artist

**AUDIO:**
- Foxito - Musician - Main OST
- skybreak | jack | solaroid - Musician - Main OST

**ASSISTANCE:**
- BinBowie - Pixel Artist - Fonts, Title Cards, HUD
- MemelordCorrin - Pixel Artist - HUD, Miscellaneous
- NintendOni - Art Designer, Assistance

**PREVIOUS TEAM MEMBERS:**
- RSM

